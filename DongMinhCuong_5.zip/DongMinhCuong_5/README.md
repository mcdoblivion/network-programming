## Bài thực hành 5: Viết chương trình client-server giao tiếp đơn giản bằng Java

### Bài tập có sử dụng thư viện json-simple-1.1.1.jar, cách chạy code:

Dùng VSCode và Run với settings đã được cài đặt sẵn, hoặc:
  1. cd đến folder DongMinhCuong_5
  2. *javac -cp ".:./socket/json-simple-1.1.1.jar" socket/server.java* để biên dịch file *server.java*
  3. *javac socket/client.java* để biên dịch file *client.java*
  4. *java -cp ".:./socket/json-simple-1.1.1.jar" socket.server* để chạy server
  5. *java socket.client* để chạy client
